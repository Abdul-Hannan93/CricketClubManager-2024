package com.example.friday.Controller;

import com.example.friday.Client.FileOperations;
import com.example.friday.Client.Player;
import com.example.friday.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AddPlayerController {
    Stage stage;
    Main main;
    String club;
    public static List<Player> PlayerList=new ArrayList<>();
    public void setStage(Stage stage) {
        this.stage=stage;

    }
    public void setClubing(String club)
    {
        this.club=club;
    }
    @FXML
    private TextField nameField;
    @FXML
    private TextField countryField;
    @FXML
    private TextField ageField;
    @FXML
    private TextField heightField;
    //@FXML
    // private TextField clubField;
    @FXML
    private TextField positionField;
    @FXML
    private TextField numberField;
    @FXML
    private TextField salaryField;
    @FXML
    private Button addButton;

    public void initialize() {
        addButton.setOnAction(event -> addPlayer());
    }
    public void init(String club)
    {
        this.PlayerList=Main.getPlayerList();
        this.club=club;
    }

    private void addPlayer() {
        // Get inputs from the user
        String name = nameField.getText();
        String country = countryField.getText();
        String ageText = ageField.getText();
        String heightText = heightField.getText();
        String position = positionField.getText();
        String numberText = numberField.getText();
        String salaryText = salaryField.getText();

        // Validate input
        if (name.isEmpty() || country.isEmpty() || ageText.isEmpty() || heightText.isEmpty() || club.isEmpty() ||
                position.isEmpty() || salaryText.isEmpty()) {
            showAlert("Error", "Please fill all required fields.");
            return;
        }

        try {
            int age = Integer.parseInt(ageText);
            double height = Double.parseDouble(heightText);
            int number = Integer.parseInt(numberText.isEmpty() ? "-1" : numberText);  // Default to -1 if empty
            int salary = Integer.parseInt(salaryText);


            for(Player p:PlayerList)
            {
                if(p.getName().equalsIgnoreCase(name))
                {
                    showAlert("Error", "Player with the same name already exists in the list.");

                }
            }
            if(position.equalsIgnoreCase("Bowler")||position.equalsIgnoreCase("Batsman")||position.equalsIgnoreCase("AllRounder")) {
                Player player = new Player(name, country, age, height, club, position, number, salary);
                PlayerList.add(player);
                List<Player> plList = FileOperations.readFromFile();
                plList.add(player);
                FileOperations.writeToFile(plList);


                showAlert("Success", "Player added successfully!");
            }
            else {
                showAlert("Error", "Enter position of the player correctly");
            }


        } catch (NumberFormatException e) {
            showAlert("Error", "Please enter valid numeric values for age, height, jersey number, and salary.");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public void Goback(ActionEvent actionEvent) throws Exception {
        main.showHomePage(club);
    }

    public void setMain(Main main) {
        this.main=main;
    }
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
