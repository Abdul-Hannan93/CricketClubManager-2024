package com.example.friday.Controller;
import com.example.friday.Client.ClubDataBase;
import com.example.friday.Client.Player;
import com.example.friday.Client.FileOperations;
import com.example.friday.Main;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import com.example.friday.DataTransferableObject.*;
import kotlin.jvm.Synchronized;

import javax.swing.text.html.ImageView;
import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class HomePage {

    private Main main;
    private String club;
    private Stage stage;
    public static List<Player> MarketList=new ArrayList<>();
    public static List<Player> PlayerList=new ArrayList<>();
    public static List<Player> AllPlayerList=new ArrayList<>();
    @FXML
    private Button nameSearch, countrySearch, positionSearch, salarySearch, PlayerMarket, SellPlayer, confirm, back;
    @FXML
    private Button BuyPlayer, logOutButton, Refresh, PlayerInfo, countryPlayerCount;
    @FXML
    private Button maxSalary, maxAge, maxHeight, totalSalary;
    @FXML
    private Text intro, intro1, intro2 ;
    @FXML
    private TextField newField, newField1, newField2;
    @FXML
    private TableView<Player> tableView;
    @FXML
    private Label Label4;
    @FXML
    private TableColumn<Player, String> NameCol, CountryCol, AgeCol, HeightCol, ClubCol, PositionCol, NumberCol, SalaryCol;
    @FXML
    private ImageView imagination1,imagination2;

    private ObservableList<Player> ClubDataList;
    @FXML
    public void NameSearch(ActionEvent actionEvent) {
        intro.setText("Enter name of the player : ");
        visible1();
        confirm.setOnAction(e->{
                    List<Player> find=new ArrayList<>();
                    find= ClubDataBase.SearchByPlayerName(newField.getText(),AllPlayerList);
                    if(find.isEmpty()){
                        Alert alert=new Alert(Alert.AlertType.ERROR);
                        alert.setHeaderText("Error!");
                        alert.setContentText("There is no player with this name");
                        alert.showAndWait();
                    }
                    else {
                        ClubDataList = FXCollections.observableArrayList(find);

                        tableView.setEditable(true);
                        tableView.setItems(ClubDataList);
                    }
                }
        );
    }
    @FXML
    public void CountrySearch(ActionEvent actionEvent) {
        intro.setText("Enter name of the country:");
        visible1();
        confirm.setOnAction(e->{
                    List<Player>find=new ArrayList<>();
                    find= ClubDataBase.SearchByCountryName(newField.getText(),AllPlayerList);
                    if(find.isEmpty()){
                        Alert alert=new Alert(Alert.AlertType.ERROR);
                        alert.setHeaderText("Error!");
                        alert.setContentText("There is no player of this country");
                        alert.showAndWait();
                    }
                    else {
                        ClubDataList = FXCollections.observableArrayList(find);
                        tableView.setEditable(true);
                        tableView.setItems(ClubDataList);
                    }
                }
        );
    }
    @FXML
    public void PositionSearch(ActionEvent actionEvent) {
        intro.setText("Enter role(Batsman/Bowler/Allrounder) of the player:");
        visible1();
        confirm.setOnAction(e->{
                    List<Player>find=new ArrayList<>();
                    find= ClubDataBase.SearchByPosition(newField.getText(),AllPlayerList);
                    if(find.isEmpty()){
                        Alert alert=new Alert(Alert.AlertType.ERROR);
                        alert.setHeaderText("Error!");
                        alert.setContentText("There is no player with this position");
                        alert.showAndWait();
                    }
                    else {
                        ClubDataList = FXCollections.observableArrayList(find);

                        tableView.setEditable(true);
                        tableView.setItems(ClubDataList);
                    }
                }
        );
    }
    @FXML
    public void SalarySearch(ActionEvent actionEvent)
    {
        intro.setText("Enter LowerBound:");
        intro1.setText("Enter UpperBound:");
        visible2();
        confirm.setOnAction(e->{
                    List<Player>find=new ArrayList<>();
                    try{
                        int x=Integer.parseInt(newField.getText());
                        int y=Integer.parseInt(newField1.getText());
                        find= ClubDataBase.SearchBySalaryRange(x,y,AllPlayerList);
                        if(find.isEmpty()){
                            Alert alert=new Alert(Alert.AlertType.ERROR);
                            alert.setHeaderText("Error!");
                            alert.setContentText("There is no player within this salary range");
                            alert.showAndWait();
                        }
                        else {
                            ClubDataList = FXCollections.observableArrayList(find);

                            tableView.setEditable(true);
                            tableView.setItems(ClubDataList);
                        }
                    }catch (Exception ex){
                        Alert alert=new Alert(Alert.AlertType.ERROR);
                        alert.setHeaderText("Invalid input");
                        alert.setContentText("Enter double values only");
                        alert.showAndWait();
                    }
                }
        );
    }
    @FXML
    public void playerMarket(ActionEvent actionEvent) {

        back.setVisible(true);
        Refresh.setVisible(true);
        BuyPlayer.setVisible(true);
        PlayerMarket.setVisible(false);
        new Thread(()->{
            MarketList=Main.getMarketList();
            ClubDataList = FXCollections.observableArrayList(MarketList);
            tableView.setEditable(true);
            tableView.setItems(ClubDataList);
        }).start();

    }



//    @FXML
//    public void buyPlayer(ActionEvent actionEvent) {
//        Player p= tableView.getSelectionModel().getSelectedItem();
//        if(p==null){
//            Alert alert=new Alert(Alert.AlertType.ERROR);
//            alert.setHeaderText("Error!");
//            alert.setContentText("You have to select a player first");
//            alert.showAndWait();
//        }
//        else{
//            boolean b=false;
//            for(Player p1: Main.getMarketList()){
//                if(p1.getName().equalsIgnoreCase(p.getName())){
//                    b=true;
//                    break;
//                }
//            }
//            if(!b){
//                Alert alert=new Alert(Alert.AlertType.ERROR);
//                alert.setHeaderText("Error!");
//                alert.setContentText("Player already sold. Please refresh");
//                alert.showAndWait();
//            }
//            else{
//                new Thread(()->{
//                    try {
//                        p.setClub(club);
//                        MarketList.remove(p);
//                        Main.setMarketList(MarketList);
//                        PlayerList.add(p);
//                        Main.setPlayerList(PlayerList);
//                        init(club);
//                        List<Player> plList=FileOperations.readFromFile();
//                        for(Player plr:plList)
//                        {
//                            if(plr.getName().equalsIgnoreCase(p.getName()))
//                            {
//                                plList.remove(plr);
//                                plList.add(p);
//                                break;
//                            }
//                        }
//                        FileOperations.writeToFile(plList);
//                        AllPlayerList=plList;
//                        BuyPlayer buyPlayer=new BuyPlayer();
//                        buyPlayer.setPlayer(p);
//                        buyPlayer.setName(club);
//                        buyPlayer.setPlayerList(PlayerList);
//                        main.getWrapper().write(buyPlayer);
//
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }
//                    ClubDataList = FXCollections.observableArrayList(MarketList);
//
//                    tableView.setEditable(true);
//                    tableView.setItems(ClubDataList);
//                }).start();
//            }
//
//        }
//
//    }
@FXML
public void buyPlayer(ActionEvent actionEvent) {
    Player p = tableView.getSelectionModel().getSelectedItem();

    if (p == null) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setHeaderText("Error!");
        alert.setContentText("You have to select a player first");
        alert.showAndWait();
    } else {
        boolean b = false;

        for (Player p1 : Main.getMarketList()) {
            if (p1.getName().equalsIgnoreCase(p.getName())) {
                b = true;
                break;
            }
        }

        if (!b) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("Error!");
            alert.setContentText("Player already sold. Please refresh");
            alert.showAndWait();
        } else {
            new Thread(() -> {
                try {
                    // Set the club for the player
                    p.setClub(club);

                    // Update the market and player lists
                    MarketList.remove(p);
                    Main.setMarketList(MarketList);
                    PlayerList.add(p);
                    Main.setPlayerList(PlayerList);

                    // Refresh the UI list
                    Platform.runLater(() -> {
                        ObservableList<Player> updatedClubDataList = FXCollections.observableArrayList(MarketList);
                        tableView.setItems(updatedClubDataList);
                    });

                    // Update the file with the changes
                    List<Player> plList = FileOperations.readFromFile();
                    for (Player plr : plList) {
                        if (plr.getName().equalsIgnoreCase(p.getName())) {
                            plList.remove(plr);
                            plList.add(p);
                            break;
                        }
                    }
                    FileOperations.writeToFile(plList);
                    AllPlayerList = plList;

                    // Send the buy player data to the wrapper
                    BuyPlayer buyPlayer = new BuyPlayer();
                    buyPlayer.setPlayer(p);
                    buyPlayer.setName(club);
                    buyPlayer.setPlayerList(PlayerList);
                    main.getWrapper().write(buyPlayer);

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }).start();
        }
    }
}
    @FXML
    public void sellPlayer(ActionEvent actionEvent) {
        Player p = tableView.getSelectionModel().getSelectedItem();
        if (p == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("Error!");
            alert.setContentText("You have to select a player first");
            alert.showAndWait();
        }
        if (p.getClub().equalsIgnoreCase(club)) {
            new Thread(() -> {
                try {
                    PlayerList.remove(p);
                    Main.setPlayerList(PlayerList);
                    MarketList.add(p);
                    Main.setMarketList(MarketList);
                    SellPlayer sellPlayer = new SellPlayer();
                    sellPlayer.setPlayer(p);
                    sellPlayer.setName(club);
                    sellPlayer.setPlayerList(PlayerList);
                    main.getWrapper().write(sellPlayer);

                } catch (IOException e) {
                    e.printStackTrace();
                }
                ClubDataList = FXCollections.observableArrayList(PlayerList);
                tableView.setEditable(true);
                tableView.setItems(ClubDataList);
            }).start();
        }
        else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("Error!");
            alert.setContentText("You have to select a player of your club first");
            alert.showAndWait();

        }
    }

    @FXML
    public void Back(ActionEvent actionEvent) {
        try {
             main.showHomePage(club);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    @FXML
    public void MaxAge(ActionEvent actionEvent) throws IOException {
        newField2.setVisible(true);
        confirm.setVisible(true);
        back.setVisible(true);
        AllPlayerList=FileOperations.readFromFile();
        confirm.setOnAction(e->{
                    Player find;
                    find= ClubDataBase.getMaxAgePlayerInClub(newField2.getText(),AllPlayerList);
                    if(find==null){
                        Alert alert=new Alert(Alert.AlertType.ERROR);
                        alert.setHeaderText("Error!");
                        alert.setContentText("There is no player ");
                        alert.showAndWait();
                    }
                    else {
                        ClubDataList = FXCollections.observableArrayList(find);

                        tableView.setEditable(true);
                        tableView.setItems(ClubDataList);
                    }
                }
        );

    }

    @FXML
    public void MaxSalary(ActionEvent actionEvent) throws IOException {
        newField2.setVisible(true);
        confirm.setVisible(true);
        back.setVisible(true);
        AllPlayerList=FileOperations.readFromFile();
        confirm.setOnAction(e->{
                    Player find;
                    find= ClubDataBase.getMaxSalaryPlayerInClub(newField2.getText(),AllPlayerList);
                    if(find==null){
                        Alert alert=new Alert(Alert.AlertType.ERROR);
                        alert.setHeaderText("Error!");
                        alert.setContentText("There is no player");
                        alert.showAndWait();
                    }
                    else {
                        ClubDataList = FXCollections.observableArrayList(find);
                        tableView.setEditable(true);
                        tableView.setItems(ClubDataList);
                    }
                }
        );


    }
    @FXML
    public void MaxHeight(ActionEvent actionEvent) throws IOException {
        newField2.setVisible(true);
        confirm.setVisible(true);
        back.setVisible(true);
        AllPlayerList=FileOperations.readFromFile();
        confirm.setOnAction(e->{
                    Player find;
                    find= ClubDataBase.getMaxHeightPlayerInClub(newField2.getText(),AllPlayerList);
                    if(find==null){
                        Alert alert=new Alert(Alert.AlertType.ERROR);
                        alert.setHeaderText("Error!");
                        alert.setContentText("There is no player");
                        alert.showAndWait();
                    }
                    else {
                        ClubDataList = FXCollections.observableArrayList(find);
                        tableView.setEditable(true);
                        tableView.setItems(ClubDataList);
                    }
                }
        );
    }
    @FXML
    public void CountryPlayerCount(ActionEvent actionEvent) {
        try {
            main.showCountryPlayerCount(club,PlayerList);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    @FXML
    public void TotalSalary(ActionEvent actionEvent) {
        back.setVisible(true);
        long total=ClubDataBase.TotalSalary(PlayerList);
        Alert alert=new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText("Yearly Salary");
        String s="Total salary of club  = " +club + " is "+ String.format("%d",total);
        alert.setContentText(s);
        alert.showAndWait();

    }
    @FXML
    public void logoutAction(ActionEvent actionEvent) {
        try {
            main.showLoginPage();
            PlayerList.clear();
            Main.setPlayerList(PlayerList);
            MarketList.clear();
            Main.setMarketList(MarketList);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @FXML
    public void ChangePass(ActionEvent actionEvent) throws Exception {
        main.changePassword(club);
    }
    @FXML
    public void AddPlay(ActionEvent actionEvent) throws Exception {
        main.showAddPlayerPage(club);
    }
    @FXML
    public void refresh(ActionEvent actionEvent) {

            new Thread(()->{
                MarketList=Main.getMarketList();
                ClubDataList = FXCollections.observableArrayList(MarketList);

                tableView.setEditable(true);
                tableView.setItems(ClubDataList);
            }).start();

    }
@FXML
    public void init(String userName) throws IOException {
        club=userName;
        PlayerList=Main.getPlayerList();
        MarketList=Main.getMarketList();
        AllPlayerList=FileOperations.readFromFile();
        Label4.setText("Welcome : "+userName);

    }

    public void setMain(Main main) {
        this.main=main;
    }
   private boolean in=true;
    public void load() {
        if (in) {
            initializeColumns();
            in = false;
        }

        ClubDataList = FXCollections.observableArrayList(PlayerList);

        tableView.setEditable(true);
        tableView.setItems(ClubDataList);
    }

    private void initializeColumns() {
        NameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

        CountryCol.setCellValueFactory(new PropertyValueFactory<>("country"));

        AgeCol.setCellValueFactory(new PropertyValueFactory<>("age"));

        HeightCol.setCellValueFactory(new PropertyValueFactory<>("height"));

        ClubCol.setCellValueFactory(new PropertyValueFactory<>("club"));

        PositionCol.setCellValueFactory(new PropertyValueFactory<>("position"));

        NumberCol.setCellValueFactory(new PropertyValueFactory<>("number"));

        SalaryCol.setCellValueFactory(new PropertyValueFactory<>("weeklySalary"));

        //buttonCol.setCellValueFactory(new PropertyValueFactory<>("button"));
    }


    public void setStage(Stage stage) {
        this.stage =stage;
    }
    private void visible1(){
        intro.setVisible(true);
        newField.setVisible(true);
        confirm.setVisible(true);
        back.setVisible(true);
    }
    private void visible2(){
        visible1();
        intro1.setVisible(true);
        newField1.setVisible(true);
    }

}
