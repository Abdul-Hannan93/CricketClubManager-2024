//package com.example.friday.server;
//import com.example.friday.DataTransferableObject.*;
//import com.example.friday.Client.Player;
//import com.example.friday.util.SocketWrapper;
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//public class ReadThreadServer implements Runnable{
//    private final Thread thr;
//    private final SocketWrapper wrapper;
//    public HashMap<String, String> userMap;
//    public List<SocketWrapper> clientList;
//    public ReadThreadServer(HashMap<String, String> map, SocketWrapper wrapper, List<SocketWrapper> cList) {
//        this.userMap = map;
//        this.wrapper = wrapper;
//        this.clientList=cList;
//        this.thr = new Thread(this);
//        thr.start();
//    }
//    public void run() {
//        try {
//            while (true) {
//                Object o = wrapper.read();
//                if (o != null) {
//                    if (o instanceof LoginObject) {
//                        LoginObject loginDTO = (LoginObject) o;
//                        String password = userMap.get(loginDTO.getUserName());
//                        loginDTO.setStatus(loginDTO.getPassword().equals(password));
//                        wrapper.write(loginDTO);
//                    }
//
//                    if(o instanceof GetPlayer){
//                        new Thread(()-> {
//                            String s = ((GetPlayer) o).getName();
//                            List<Player> ClubPlayerList = new ArrayList<>();
//                            List<Player> ClubMarketList = new ArrayList<>();
//                            for (Player p : Server.getPlayerList()) {
//                                //System.out.println(p);
//                                if (p.getClub().equalsIgnoreCase(s)) {
//                                    ClubPlayerList.add(p);
//                                }
//                            }
//
//                            for(Player p: Server.getMarketList()){
//                                if(!(p.getClub().equalsIgnoreCase(s))){
//                                    ClubMarketList.add(p);
//                                }
//                            }
//
//                            GetPlayerResponse getPlayerList = new GetPlayerResponse();
//                            getPlayerList.setPlayerList(ClubPlayerList);
//                            getPlayerList.setMarketList(ClubMarketList);
//
//                            try {
//                                wrapper.write(getPlayerList);
//                            } catch (IOException e) {
//                                e.printStackTrace();
//                            }
//                        }).start();
//                    }
//
//                    if(o instanceof SellPlayer){
//                        new Thread(()-> {
//                            Player p = ((SellPlayer) o).getPlayer();
//                            List<Player> ClubPlayerList=((SellPlayer) o).getPlayerList();
//                            String club=((SellPlayer) o).getName();
//                            List<Player> playerList=Server.getPlayerList();
//                            for(Player pl: playerList){
//                                if(pl.getName().equalsIgnoreCase(p.getName())){
//                                    playerList.remove(pl);
//                                    break;
//                                }
//                            }
//                            Server.setPlayerList(playerList);
//                            List<Player> MarketList = Server.getMarketList();
//                            MarketList.add(p);
//                            Server.setMarketList(MarketList);
//
//                            SellPlayerResponse getSellList = new SellPlayerResponse();
//                            getSellList.setPlayerList(ClubPlayerList);
//                            getSellList.setMarketList(MarketList);
//
//                            try {
//                                for(SocketWrapper n: clientList){
//                                    n.write(getSellList);
//                                }
//                            } catch (IOException e) {
//                                e.printStackTrace();
//                            }
//                        }).start();
//                    }
//
//                    if(o instanceof BuyPlayer){
//                        new Thread(()-> {
//                            Player p = ((BuyPlayer) o).getPlayer();
//                            List<Player> ClubPlayerList=((BuyPlayer) o).getPlayerList();
//                            List<Player> playerList=Server.getPlayerList();
//                            for(Player pl: playerList){
//                                if(pl.getName().equalsIgnoreCase(p.getName())){
//                                    playerList.remove(pl);
//                                    break;
//                                }
//                            }
//                            playerList.add(p);
//                            Server.setPlayerList(playerList);
//                            //String club=((SellPlayer) o).getName();
//                            List<Player> MarketList = Server.getMarketList();
//                            for(Player pl: MarketList){
//                                if(pl.getName().equalsIgnoreCase(p.getName())){
//                                    MarketList.remove(pl);
//                                    break;
//                                }
//                            }
//                            Server.setMarketList(MarketList);
//
//                            BuyPlayerResponse getBuyList = new BuyPlayerResponse();
//                            getBuyList.setPlayerList(ClubPlayerList);
//                            getBuyList.setMarketList(MarketList);
//
//                            try {
//                                for(SocketWrapper n: clientList){
//                                    n.write(getBuyList);
//                                }
//                            } catch (IOException e) {
//                                e.printStackTrace();
//                            }
//                        }).start();
//                    }
//                }
//            }
//        } catch (Exception e) {
//            System.out.println(e);
//        } finally {
//            try {
//                wrapper.closeConnection();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//    }
//}
package com.example.friday.server;

import com.example.friday.DataTransferableObject.*;
import com.example.friday.Client.Player;
import com.example.friday.util.SocketWrapper;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
public class ReadThreadServer implements Runnable {
    private final Thread thr;
    private final SocketWrapper wrapper;
    public HashMap<String, String> userMap;
    public List<SocketWrapper> clientList;


    public ReadThreadServer(HashMap<String, String> map, SocketWrapper wrapper, List<SocketWrapper> cList) {
        this.userMap = map;
        this.wrapper = wrapper;
        this.clientList = cList;
        this.thr = new Thread(this);
        thr.start();
    }

    @Override
    public void run() {
        try {
            while (true) {
                Object o = wrapper.read();
                if (o != null) {
                    if (o instanceof LoginObject) {
                        LoginObject loginDTO = (LoginObject) o;
                        String password = userMap.get(loginDTO.getUserName());
                        loginDTO.setStatus(loginDTO.getPassword().equals(password));
                        wrapper.write(loginDTO);
                    }

                    if (o instanceof GetPlayer) {
                        new Thread(() -> {
                            String s = ((GetPlayer) o).getName();
                            List<Player> ClubPlayerList = new ArrayList<>();
                            List<Player> ClubMarketList = new ArrayList<>();

                            synchronized (Server.class) {
                                for (Player p : Server.getPlayerList()) {
                                    if (p.getClub().equalsIgnoreCase(s)) {
                                        ClubPlayerList.add(p);
                                    }
                                }

                                for (Player p : Server.getMarketList()) {
                                    if (!(p.getClub().equalsIgnoreCase(s))) {
                                        ClubMarketList.add(p);
                                    }
                                }
                            }

                            GetPlayerResponse getPlayerList = new GetPlayerResponse();
                            getPlayerList.setPlayerList(ClubPlayerList);
                            getPlayerList.setMarketList(ClubMarketList);

                            try {
                                wrapper.write(getPlayerList);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }).start();
                    }

                    if (o instanceof SellPlayer) {
                        new Thread(() -> {
                            Player p = ((SellPlayer) o).getPlayer();
                            List<Player> ClubPlayerList = ((SellPlayer) o).getPlayerList();
                            String club = ((SellPlayer) o).getName();
                            List<Player> playerList;
                            List<Player> MarketList;

                            synchronized (Server.class) { // Synchronize shared resources access
                                playerList = new ArrayList<>(Server.getPlayerList());
                                for (Player pl : playerList) {
                                    if (pl.getName().equalsIgnoreCase(p.getName())) {
                                        playerList.remove(pl);
                                        break;
                                    }
                                }

                                MarketList = new ArrayList<>(Server.getMarketList());
                                MarketList.add(p);
                                Server.setPlayerList(playerList);
                                Server.setMarketList(MarketList);
                            }

                            SellPlayerResponse getSellList = new SellPlayerResponse();
                            getSellList.setPlayerList(ClubPlayerList);
                            getSellList.setMarketList(MarketList);

                            try {
                                synchronized (clientList) {
                                    for (SocketWrapper n : clientList) {
                                        n.write(getSellList);
                                    }
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }).start();
                    }

                    if (o instanceof BuyPlayer) {
                        new Thread(() -> {
                            Player p = ((BuyPlayer) o).getPlayer();
                            List<Player> ClubPlayerList = ((BuyPlayer) o).getPlayerList();
                            List<Player> playerList;
                            List<Player> MarketList;

                            synchronized (Server.class) {
                                playerList = new ArrayList<>(Server.getPlayerList());
                                for (Player pl : playerList) {
                                    if (pl.getName().equalsIgnoreCase(p.getName())) {
                                        playerList.remove(pl);
                                        break;
                                    }
                                }

                                playerList.add(p);
                                Server.setPlayerList(playerList);

                                MarketList = new ArrayList<>(Server.getMarketList());
                                for (Player pl : MarketList) {
                                    if (pl.getName().equalsIgnoreCase(p.getName())) {
                                        MarketList.remove(pl);
                                        break;
                                    }
                                }

                                Server.setMarketList(MarketList);
                            }

                            BuyPlayerResponse getBuyList = new BuyPlayerResponse();
                            getBuyList.setPlayerList(ClubPlayerList);
                            getBuyList.setMarketList(MarketList);

                            try {
                                synchronized (clientList) {
                                    for (SocketWrapper n : clientList) {
                                        n.write(getBuyList);
                                    }
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }).start();
                    }
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            try {
                wrapper.closeConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
