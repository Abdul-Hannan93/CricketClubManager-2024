package com.example.friday.DataTransferableObject;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.property.SimpleStringProperty;

public class CountryPlayerCount {
    private final StringProperty countryName;
    private final IntegerProperty playerCount;

    public CountryPlayerCount(String countryName, int playerCount) {
        this.countryName = new SimpleStringProperty(countryName);
        this.playerCount = new SimpleIntegerProperty(playerCount);
    }

    public StringProperty countryNameProperty() {
        return countryName;
    }

    public IntegerProperty playerCountProperty() {
        return playerCount;
    }

    public String getCountryName() {
        return countryName.get();
    }

    public int getPlayerCount() {
        return playerCount.get();
    }
}
