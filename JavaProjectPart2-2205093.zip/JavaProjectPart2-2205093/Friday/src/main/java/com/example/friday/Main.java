package com.example.friday;
import com.example.friday.Controller.*;
import com.example.friday.Client.Player;
import javafx.application.Application;
import com.example.friday.Client.ReadThread;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import com.example.friday.util.SocketWrapper;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
public class Main extends Application {
    private Stage stage;
    private SocketWrapper wrapper;
    public static List<Player> playerList=new ArrayList<>();
    public static List<Player> marketList=new ArrayList<>();
    public Stage getStage() {
        return stage;
    }
    public SocketWrapper getWrapper() {
        return wrapper;
    }
    public static List<Player> getPlayerList() {
        return playerList;
    }
    public static void setPlayerList(List<Player> playerList) {
        Main.playerList = playerList;
    }
    public static List<Player> getMarketList() {
        return marketList;
    }
    public static void setMarketList(List<Player> marketList) {
        Main.marketList = marketList;
    }
    @Override
    public void start(Stage primaryStage) throws Exception {
        stage = primaryStage;
        connectToServer();
        showLoginPage();
    }
    private void connectToServer() throws IOException {
        String serverAddress = "127.0.0.1";
        int serverPort = 8888;
        wrapper = new SocketWrapper(serverAddress, serverPort);
        new ReadThread(this);
    }
    public void showLoginPage() throws Exception {
        System.out.println("1");
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("Login.fxml"));
        Parent root = fxmlLoader.load();
        LoginController controller = fxmlLoader.getController();
        controller.init();
        controller.setMain(this);
        controller.setStage(stage);
        stage.setTitle("Login");
        stage.setScene(new Scene(root,600,600
        ));
        stage.show();
    }


    public void showHomePage(String userName) throws Exception {
        System.out.println("2");
        FXMLLoader fxmlLoader=new FXMLLoader(Main.class.getResource("HomePage.fxml"));
        Scene scene =new Scene(fxmlLoader.load(),815,1700);
        HomePage controller = fxmlLoader.getController();
        controller.init(userName);
        controller.load();
        controller.setMain(this);
        controller.setStage(stage);
        stage.setTitle("Home");
        stage.setScene(scene);
        stage.show();
    }
    public void showCountryPlayerCount(String club, List<Player> playerList) throws Exception{
        FXMLLoader fxmlLoader=new FXMLLoader(Main.class.getResource("countryPlayer.fxml"));
        Scene scene =new Scene(fxmlLoader.load(),400,500);
        CountryPlayerController controller = fxmlLoader.getController();
        controller.init(club,playerList);
        controller.setMain(this);
        controller.setStage(stage);
        stage.setTitle("Country Player Count");
        stage.setScene(scene);
        stage.show();
        controller.load();
    }
    public void changePassword(String club) throws Exception
    {
        FXMLLoader fxmlLoader=new FXMLLoader(Main.class.getResource("changePassword.fxml"));
        Scene scene =new Scene(fxmlLoader.load(),400,400);
        ClubPasswordController controller=fxmlLoader.getController();
        controller.setClubing(club);
        controller.setStage(stage);
        controller.setMain(this);
        stage.setTitle("Add Player");
        stage.setScene(scene);
        stage.show();
    }
  public void showAddPlayerPage(String club) throws Exception{
       FXMLLoader fxmlLoader=new FXMLLoader(Main.class.getResource("AddPlayer.fxml"));
       Scene scene =new Scene(fxmlLoader.load(),600,700);
       AddPlayerController controller=fxmlLoader.getController();
       controller.setStage(stage);
       controller.setMain(this);
       controller.init(club);
       controller.setClubing(club);
       stage.setTitle("Add Player");
       stage.setScene(scene);
       stage.show();
  }
    public void showAlert() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Incorrect Credentials");
        alert.setHeaderText("Incorrect Credentials");
        alert.setContentText("The username and password you provided is not correct.");
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
